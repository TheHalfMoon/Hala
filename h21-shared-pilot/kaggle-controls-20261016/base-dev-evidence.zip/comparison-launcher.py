"""Fixed operational launcher: same published runtime, frozen tasks and retained asset."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

root = Path('/kaggle/working/hala-h21')
source = root / 'source'
commit = '11a3a5359afa896787198e0492ccd036d0b6f4f8'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == commit
qualification = json.loads((root / 'qualification.json').read_text())
assert qualification['source_commit'] == commit
assert qualification['runtime_sha256'] == 'cbc80167c80461a267a7232b0596ccf176c0c118dbf7772128a92798ee0fca2e'
assert qualification['cuda'] and qualification['pillow'] == '11.3.0' and qualification['raqm'] == '0.10.1'
assert qualification['font_sha256'] == 'ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280'
assert qualification['disk_free_bytes'] >= 12 * 1024**3
assert json.loads((root / 'preparation.json').read_text())['all_pngs_match']
assert os.environ.get('KAGGLE_KERNEL_RUN_TYPE') == 'Interactive'
results = root / 'comparison'
results.mkdir(exist_ok=False)
env = dict(os.environ, HALA_REMOTE_DEVELOPMENT_ALLOWED='1', PYTHONIOENCODING='utf-8')
report = {'schema': 'hala.h21.kaggle.fixed_comparison_launcher.v1', 'source_commit': commit,
          'training_runs': 0, 'adapter_changed': False, 'runs': [], 'status': 'running'}
def save():
    path = results / 'launcher-status.json'
    temp = path.with_suffix('.partial')
    temp.write_text(json.dumps(report, indent=2) + '\n')
    temp.replace(path)
save()
for kind, split in (('base', 'dev'), ('base', 'test'), ('adapter', 'dev'), ('adapter', 'test')):
    name = kind + '-' + split
    output = results / name
    args = [sys.executable, '-u', '-m', 'evaluation.development_runtime', '--provider', 'kaggle',
            '--bundle', str(root / 'frozen'), '--manifest-sha256',
            'ced87ae6874df6de2ed1ab853312824084191a29a42b97869f6eb462aceb629e',
            '--output', str(output), '--font-path', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
            '--source-commit', commit, '--split', split, '--cache-dir', '/tmp/hala-h21-cache']
    if kind == 'adapter':
        args += ['--adapter', str(root / 'retained-adapter'), '--adapter-manifest-sha256',
                 '7e46995aa694e5782a93d4beb6139cc5880b898a2038eb2d2ce2a2d8006a841d',
                 '--adapter-base-model', 'Qwen/Qwen3-VL-2B-Instruct', '--adapter-base-revision',
                 '89644892e4d85e24eaac8bacfd4f463576704203', '--adapter-source-commit',
                 '5b6eb4bf29acbaf21aa199f113f78af4f268b3b7', '--adapter-data-sha256',
                 'af540e4db2289540fb8adecd0665439c4d6055ffc86673a3286e902c86c0340e',
                 '--adapter-evaluation-sha256', 'e9f98694089d5411d3a6c570c7de2ede8f82cbeb3132e47904d17301030c0768']
    record = {'name': name, 'argv': args, 'status': 'running', 'started_unix': time.time()}
    report['runs'].append(record)
    save()
    log = results / (name + '.log')
    with log.open('wb') as stream:
        try:
            run = subprocess.run(args, cwd=source, env=env, stdout=stream,
                                 stderr=subprocess.STDOUT, timeout=3700)
            record.update(returncode=run.returncode, status='finished' if run.returncode == 0 else 'failed')
        except subprocess.TimeoutExpired:
            record.update(returncode=None, status='outer_launcher_timeout')
    record['finished_unix'] = time.time()
    result = output / 'result.json'
    if result.is_file():
        raw = result.read_bytes()
        measured = json.loads(raw)
        record.update(result_sha256=hashlib.sha256(raw).hexdigest(), result_status=measured['status'],
                      adapter_loaded=measured['adapter_loaded'], summary=measured.get('summary'))
    save()
    archive = results / (name + '-evidence.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(output.rglob('*')) if output.is_dir() else []:
            if path.is_file():
                assert path.stat().st_size <= 8 * 1024**2
                z.write(path, str(path.relative_to(results)))
        z.write(log, log.name)
        for name_ in ('qualification.json', 'preparation.json'):
            z.write(root / name_, name_)
        z.write(Path(__file__), 'comparison-launcher.py')
    record.update(archive_name=archive.name, archive_bytes=archive.stat().st_size,
                  archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
    save()
    print('HALA_RUN_COMPLETE:' + json.dumps(record, sort_keys=True), flush=True)
    if record['status'] != 'finished' or record.get('result_status') != 'measured':
        report['status'] = 'blocked'
        break
else:
    report['status'] = 'finished'
save()
print('HALA_COMPARISON_COMPLETE:' + json.dumps(report, sort_keys=True), flush=True)
