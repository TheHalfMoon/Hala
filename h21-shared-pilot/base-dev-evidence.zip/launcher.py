import subprocess
import sys
import os
import pathlib
import json
import hashlib

# Define paths and configuration parameters
repo_dir = pathlib.Path('/content/hala-model-development')
bundle_path = pathlib.Path('/tmp/hala-h21-frozen')
manifest_sha = 'ced87ae6874df6de2ed1ab853312824084191a29a42b97869f6eb462aceb629e'
font_path = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
cache_dir = pathlib.Path('/tmp/hala-h21-cache')

# Configure clean environments
base_env = {
    **os.environ,
    'HALA_REMOTE_DEVELOPMENT_ALLOWED': '1',
    'HF_HUB_DISABLE_TELEMETRY': '1',
    'DO_NOT_TRACK': '1'
}

def evaluate_split(split_name, out_dir_path, log_path):
    out_dir = pathlib.Path(out_dir_path)
    log_p = pathlib.Path(log_path)
    
    # Assert output directory and log do not exist to let the runtime create them
    assert not out_dir.exists(), f"Output directory {out_dir} already exists."
    assert not log_p.exists(), f"Log path {log_p} already exists."
    
    print(f"Starting baseline evaluation for split: {split_name}...", flush=True)
    
    cmd = [
        sys.executable, '-m', 'evaluation.development_runtime',
        '--bundle', str(bundle_path),
        '--split', split_name,
        '--output', str(out_dir),
        '--font-path', font_path,
        '--cache-dir', str(cache_dir),
        '--manifest-sha256', manifest_sha,
        '--source-commit', '6b9bdff139d57ca29d0e4c5774c2d71805e8188e'
    ]
    
    try:
        with log_p.open('x') as log_file:
            subprocess.run(
                cmd,
                cwd=str(repo_dir),
                env=base_env,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                timeout=3700,
                check=True
            )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        print(f"\nEvaluation of {split_name} failed or timed out! Tail of log:", flush=True)
        if log_p.exists():
            lines = log_p.read_text(errors='replace').splitlines()
            for line in lines[-50:]:
                print(line, flush=True)
        raise e
        
    print(f"Finished baseline evaluation for split: {split_name}.\n", flush=True)
    
    # Verification and metadata gathering
    result_json_path = out_dir / 'result.json'
    assert result_json_path.is_file(), f"Result file {result_json_path} was not created."
    
    result_bytes = result_json_path.read_bytes()
    result_sha = hashlib.sha256(result_bytes).hexdigest()
    result_data = json.loads(result_bytes.decode('utf-8'))
    
    # Assertion validations
    assert result_data.get('status') == 'measured', f"Unexpected status: {result_data.get('status')}"
    assert result_data.get('adapter_loaded') is False, "Adapter must not be loaded for baseline evaluations."
    assert result_data.get('training_runs') == 0, "Training runs count must be zero for baseline evaluations."
    
    split_report = {
        'split': split_name,
        'result_file_bytes': len(result_bytes),
        'result_file_sha256': result_sha,
        'status': result_data.get('status'),
        'summary': result_data.get('summary'),
        'gpu': result_data.get('gpu'),
        'wall_seconds': result_data.get('wall_seconds'),
        'memory_loaded': result_data.get('memory_loaded'),
        'max_sampled_device_used_bytes': result_data.get('max_sampled_device_used_bytes'),
        'model_generation_seconds': result_data.get('model_generation_seconds')
    }
    
    return split_report

# Run evaluations sequentially
dev_report = evaluate_split('dev', '/tmp/hala-h21-base-dev-r1', '/tmp/hala-h21-base-dev-r1.log')
test_report = evaluate_split('test', '/tmp/hala-h21-base-test-r1', '/tmp/hala-h21-base-test-r1.log')

# Print structured baseline outputs
print('HALA_BASELINE_RESULT:', json.dumps({
    'dev': dev_report,
    'test': test_report
}, indent=2))